WebPPL Reference Manual (Executable Examples)
===========================================

This documentation style is aimed at being **Coq/Rocq-like** in one specific way:
**every snippet is meant to be runnable**, and the docs build can execute examples.

.. toctree::
   :maxdepth: 2
   :caption: Contents

   philosophy
   data_shapes
   distributions/index
   cookbook/index
