Cookbook (patterns and "when to use what")
=========================================

Unlike a flat API list, this section groups things by **decision points**:

.. toctree::
   :maxdepth: 2

   options_objects
   arrays_vs_tensors
